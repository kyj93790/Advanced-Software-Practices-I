import numpy as np
import math

def getInput(lines):
	points = []
	for line in lines:
		x, y = line.split()
		x, y = int(x), int(y)
		points.append([x, y])
	return points

def calc_cross(p1, p2, y):
    if (p1[1] - p2[1]) == 0:
        return False, 0
    elif p1[1] == y:
        return True, p1[0]
    elif p2[1] == y:
        return True, p2[0]
    
    if p1[1] > y and p2[1] > y:
        return False, 0
    if p1[1] < y and p2[1] < y:
        return False, 0
    crs = (y - p1[1])*(p2[0] - p1[0])/(p2[1] - p1[1]) + p1[0]
    #print(crs)
    return True, crs

def count_cross(cvh, p):
    cnt = 0
    crs_list = []
    for i in range(len(cvh)-1):
        success, crs = calc_cross(cvh[i], cvh[i+1], p[1])
        if success == False:
            continue
        if p[1] == cvh[i][1] or p[1] == cvh[i+1][1]:
            crs_list.append([crs, 1])
        else:
            crs_list.append([crs, 0])
    success, crs = calc_cross(cvh[len(cvh)-1], cvh[0], p[1])
    if success:
        if p[1] == cvh[len(cvh)-1][1] or p[1] == cvh[0][1]:
            crs_list.append([crs, 1])
        else:
            crs_list.append([crs, 0])

    sorted(crs_list)
    #print(crs_list)
    #print("p[0] : " + str(p[0]))
    for crs, _ in crs_list:
        if crs <= p[0]:
            continue
        cnt = cnt+1
    #if len(crs_list) > 2 and crs_list[-1][1] == 1:
    #    cnt = cnt-1
    return cnt


def check(i_name, o_name, check_points):
    in_file = open(i_name, "r")
    out_file = open(o_name, "w")
    lines = in_file.readlines()
    
    # convex hull coordinate
    cvh = []
    for i in range(1, len(lines)):
        x, y = lines[i].split()
        cvh.append([int(x), int(y)])
    
    for p in check_points:
        cnt = count_cross(cvh, p)
        #print("cnt : " + str(cnt))
        if cnt % 2 == 0:
            out_file.write("out\n")
        else:
            out_file.write("in\n")

    in_file.close()
    out_file.close()

p_file = open("point_in_polygon_input.txt", "r")
lines = p_file.readlines() # read check points
points = getInput(lines)

check("output1.txt", "point_in_polygon_output1.txt", points)
check("output2.txt", "point_in_polygon_output2.txt", points)
check("output3.txt", "point_in_polygon_output3.txt", points)

p_file.close()