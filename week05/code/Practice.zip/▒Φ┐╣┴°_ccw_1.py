import numpy as np
import math
import display

def ccw(top, next_to_top, point):
	a = np.array([top[0]-next_to_top[0], top[1]-next_to_top[1]])
	b = np.array([point[0]-top[0], point[1]-top[1]])
	return np.cross(a, b)
	

def convex_hull(points, pts):
	stack = []
	p = points[0]

	stack.append(p)
	for i in range(1, len(points)):
		point = points[pts[i]]
		while len(stack) > 1 and ccw(stack[-1], stack[-2], point) <= 0:
			stack.pop(-1)
		stack.append(point)
	return stack

def sorting(points):
	result = []
	angles = []

	points.sort(key = lambda x:x[1])
	p0 = points[0]
	for i in range(1, len(points)):
		a = math.atan2(p0[1]-points[i][1], p0[0]-points[i][0])
		angles.append([i, a])

	angles.sort(key = lambda x:x[1])
	result.append(0)
	for i in range(len(angles)):
		result.append(angles[i][0])
	return (result)	

def areaOfTri(p1, p2):
	v1 = np.array(p1)
	v2 = np.array(p2)
	return np.cross(v1, v2)/2

def areaOfConvex(polygon):
	sum = 0
	for i in range(len(polygon)-1):
		sum += areaOfTri(polygon[i], polygon[i+1])
	# last
	sum += areaOfTri(polygon[-1], polygon[0])
	return sum

def getInput(lines):
	points = []
	for line in lines:
		x, y = line.split()
		x, y = int(x), int(y)
		points.append([x, y])
	return points

def printResult(out_file, area, polygon):
	out_file.write(str(area) + '\n')
	for p in polygon:
		out_file.write(str(p[0]) + ' ' + str(p[1]) + '\n')

def solve(i_name, o_name):
	in_file = open(i_name, "r")
	out_file = open(o_name, "w")
	lines = in_file.readlines()
	points = getInput(lines)

	pts = sorting(points)
	cvh = convex_hull(points, pts)
	# print(cvh)
	area = areaOfConvex(cvh)
	# print(area)
	printResult(out_file, area, cvh)
	
	in_file.close()
	out_file.close()
	display.display(i_name, o_name)


solve("input1.txt", "output1.txt")
solve("input2.txt", "output2.txt")
solve("input3.txt", "output3.txt")
