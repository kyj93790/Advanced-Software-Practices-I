import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.interpolate import splprep, splev
from scipy.optimize import minimize
import time


class LateralController:
    '''
    Lateral control using the Stanley controller

    functions:
        stanley 

    init:
        gain_constant (default=5)
        damping_constant (default=0.5)
    '''


    def __init__(self, gain_constant=5, damping_constant=0.6):

        self.gain_constant = gain_constant
        self.damping_constant = damping_constant
        self.previous_steering_angle = 0


    def stanley(self, waypoints, speed):
        '''
        ##### TODO #####
        one step of the stanley controller with damping
        args:
            waypoints (np.array) [2, num_waypoints]
            speed (float)
        '''

        # derive orientation error as the angle of the first path segment to the car orientation
        # 차의 방향 계산
        epsilon = 0.000001

        diff = waypoints[:, 1] - waypoints[:, 0]
        psi = np.arctan(diff[0] / diff[1])
        ctrl_law = psi

        # derive stanley control law
        # derive cross track error as distance between desired waypoint at spline parameter equal zero ot the car position
        # 1인칭 시점이므로 x로 ERROR calc
        cross_err = waypoints[0, 0] - 48

        # prevent division by zero by adding as small epsilon 
        ctrl_law += np.arctan(self.gain_constant * cross_err / (speed + epsilon))

        # derive damping
        delta = ctrl_law - self.damping_constant * (ctrl_law - self.previous_steering_angle)
        self.previous_steering_angle = delta

        # clip to the maximum stering angle (0.4) and rescale the steering action space
        rescaled_delta = np.clip(delta, -0.4, 0.4) / 0.8        

        """
        crosstrack error : waypoints의 맨 처음값 - (48,0)
        heading error : waypoints의 첫 번째 인덱스 값과 그 다음 인덱스에 해당되는 값 사용
        """
        # return : delta
        return rescaled_delta







